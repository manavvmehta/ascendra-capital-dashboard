# Data formats

There is no database. Everything is flat JSON (and two CSVs) in `DATA/`, read
and written whole. No migrations, no ORM, no schema enforcement — if you change
a field name you must change every reader, including the JavaScript in
`ascendra_desk.html`.

Writes are always atomic: write `*.tmp`, then `os.replace`. Keep that; three
processes write into this folder and the dashboard reads it while they do.

## Files in this zip

| File | Written by | What it is |
|---|---|---|
| `formations_log.json` | `FORMATIONS LIVE.py` | **the Patterns record** — every call ever made, keyed. 134 entries here. |
| `smc2_log.json` | `SMC NEW.py` | the SMC record. `{}` in this zip — the engine is new and had made no call yet. |
| `cmd_log.json` | `COMMODITIES LIVE.py` | the Commodities record. `{}` here. |
| `fo_universe.json` | (maintained by hand) | the F&O names, 219 of them, as `{"map": {SYMBOL: ...}}` |
| `ind_niftytotalmarket_list.csv` | NSE download | `Company Name, Industry, Symbol, Series, ISIN Code` — 755 rows. The **only** source of a stock's industry, and of its `Series` (`EQ` or `BE`). |
| `mcap_1000cr.json` | `BUILD UNIVERSE.py` | `{"as_of", "min_cr", "source", "caps": {SYMBOL: crore}}` — 1,405 companies over ₹1,000 crore |
| `CHECK THE RECORD.py` | — | audit script for the record files |

### Not in this zip, and why

`formations_daily.json`, `smc2_daily.json`, `mcx_daily.json`,
`mcx_intraday.json`, `3y_parts/`, `5m_parts/` — daily candle caches and bulk
15-minute history, several gigabytes. Every one is re-downloadable from
Zerodha; the engines rebuild the caches on their first scan of the day. Also
excluded: `kite_keys.txt` and `kite_token.json` (live API secret).

## The record format

All three records are a flat dict: `{key: call}`. The key is built from the
setup so the same setup is never recorded twice:

```
"ABB|SWING|DOUBLE-TOP|2026-10-21"      symbol | section | pattern | date found
```

A Patterns call, with the two bulky fields removed:

```json
{
  "sym": "ABB", "section": "SWING", "pattern": "DOUBLE-TOP", "side": "SHORT",
  "state": "WAITING", "status": "WAITING", "at": "2026-10-21",
  "first_seen": "2026-10-23T09:25:34",

  "entry": 6660.5, "stop": 7405.5, "target": 5814.5, "line": 6660.5,
  "last": 6144.0, "risk_pct": 11.19, "reward_pct": 12.7, "rr": 1.14,

  "rating": 0, "score": 50.0,
  "why": ["weak formation", "NOT THIS SHAPE - peaks within 1% of each other"],
  "crit": { "peaks within 1% of each other": false,
            "at least a 10% fall between them": true,
            "the peaks are weeks apart": false,
            "volume recedes while it forms": false,
            "volume expands on the breakout": true,
            "breaks out promptly": true },

  "ind": { "ema20": 6933.03, "ema50": 7092.33, "rsi": 36.8,
           "macd_hist": -4.102, "vol_x": 2.67, "atr_pct": 3.44 },
  "sec": "Capital Goods", "vs_sec": -3.0, "breadth": 10.0, "trend50": true,
  "vol": true, "cand": 1, "cand_names": ["marubozu", "belt_hold", "engulfing"],
  "ph": [51, 60], "pl": [56], "tb": 70, "eb": 26,

  "filled_at": null, "closed_at": null, "exit_px": null, "result_pct": null,
  "D": [[o,h,l,c], ...], "H": [[o,h,l,c], ...]
}
```

Field notes that are not obvious:

- **`rating`** 0–10, and the dashboard hides anything below `PAT.FLOOR = 8`.
  So a record full of rating-0 entries is normal: the engine keeps everything
  it evaluated, and the page filters. `crit` and `why` are the audit trail of
  *why* the rating came out as it did — keep them, they are how the owner
  checks the engine's reasoning.
- **`section`** is the chart the setup was found on (`SWING` = daily,
  `INTRADAY` = hourly), **not** the holding period. The page maps it to a
  money pot, and the mapping crosses over — see `ARCHITECTURE.md`.
- **`state`** / **`status`** — `WAITING → BROKE → IN → DONE`, or `GONE` if the
  level was never taken. `BROKE` must stay visible on the dashboard.
- **`last`** is the live price, rewritten every minute while the stock is in
  the sweep. **It freezes once the stock drops out of the live sweep**, which
  has produced wrong P&L twice. Do not treat a stale `last` as a current price;
  mark from a fresh quote or from the daily cache.
- **`result_pct`** is the realised result as a percentage, and the page turns
  it into rupees with the pot's slot. It is `null` until the call closes.
- **`D`** and **`H`** are daily and hourly candles as `[open, high, low,
  close]`, carried so the page can draw the chart without another request.
  They are most of the file's size: ~600 KB for 134 calls. If you move to an
  API, this is the first thing to stop shipping.

## The SMC record

Same shape, plus `book` (`"SHORT TERM"` or `"LONG TERM"`) and the publish
payload groups by book:

```json
{"as_of": "...", "slot": 200000.0,
 "books": {"SHORT TERM": {"chart": "...", "note": "...",
                          "waiting": [], "open": [], "closed": [],
                          "booked": 0, "closed_n": 0, "marked": 0,
                          "open_n": 0, "missed_n": 0, "wins": 0}},
 "px": {}, "px_at": null, "px_err": ""}
```

`booked` is realised rupees, `marked` is unrealised on open positions. Both are
computed in the engine from `result_pct` and `last`, so they are only as good
as `last` is fresh.

## The Commodities record

```json
{"as_of": "...", "slot": 200000.0, "rule": "closes above the 20-day high, ...",
 "waiting": [], "open": [], "closed": [],
 "booked": 0, "closed_n": 0, "marked": 0, "open_n": 0, "wins": 0}
```

## Candle data, where it is cached

Not in this zip, but you will meet the format. Two shapes exist and they are
easy to confuse:

```python
# DATA/3y_parts/partNN.json  — bulk 15-minute history, list rows
{"interval": "15minute", "part": 1, "of": 5,
 "bars": {"RELIANCE": [["2023-10-02 09:15", o, h, l, c, volume], ...]}}

# DATA/formations_daily.json, smc2_daily.json — the per-day cache, dict rows
{"date": "2026-10-23",
 "bars": {"RELIANCE": [{"date": "...", "open": .., "high": .., "low": ..,
                        "close": .., "volume": ..}, ...]}}
```

The cache is keyed by `date` and only refetched when that date is not today.

## Rules that are not negotiable without asking the owner

- **Costs**, charged on the slot, round trip: cash intraday 0.059%, stock
  futures 0.062%, delivery 0.222%.
- **Slots**: ₹2 lakh intraday/swing, ₹4 lakh positional.
- **No lookahead.** A decision uses only closed candles; a fill is the *next*
  candle's open; a target is never claimed on the fill candle, though a stop
  is. Every one of these rules is in the code because breaking it once
  produced a backtest that fell apart on inspection.
- **Report money in rupees, never in risk multiples.**
