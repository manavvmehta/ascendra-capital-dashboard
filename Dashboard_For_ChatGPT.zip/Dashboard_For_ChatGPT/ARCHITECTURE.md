# How the pieces fit together

## The one thing to understand first

The dashboard does **not** fetch its data. The Python engines **write their
data into the HTML file**, between marker comments, and the browser just loads
the page.

Each engine owns one marker pair in `WEBSITE/ascendra_desk.html`:

```
/*FMLIVE_START*/const FMLIVE = { ...JSON... };/*FMLIVE_END*/      Patterns
/*SMC2_START*/const SMC2LIVE = { ...JSON... };/*SMC2_END*/        SMC
/*CMD_START*/const CMDLIVE = { ...JSON... };/*CMD_END*/           Commodities
```

The write is a string splice, then an atomic replace:

```python
a = h.index(start); b = h.index(end) + len(end)
h = h[:a] + f"{start}const FMLIVE = {payload};{end}" + h[b:]
open(tmp, "w", encoding="utf8").write(h)
os.replace(tmp, SITE)
```

Consequences a new developer must respect:

1. **Three processes write the same file.** Each touches only its own marker
   span and replaces the file atomically, so a lost update is possible but a
   corrupt file is not. Do not hold the file open.
2. **Never reformat `ascendra_desk.html` with a tool.** A prettifier will move
   or reflow the markers and the engines will append a fresh block at the end
   of the last `<script>` instead of replacing in place — you get two
   `const FMLIVE` declarations and a page that dies on a syntax error.
3. **The file is CRLF throughout.** Edits must preserve that; the spliced
   blocks contain no newlines at all, which is deliberate.
4. The page grows: a full Patterns payload is ~500 KB of JSON. Cleared, the
   page is ~340 KB; in use it reaches 1.4 MB.

### Why it is built this way

Each engine also serves its JSON on its own port (5056, 5057, 5058). That was
the original design and it does not work in practice: a page loaded from
`127.0.0.1:5055` is refused when it tries to read `127.0.0.1:5057`, so the tabs
sat there saying "not running" while the engines were running perfectly. The
in-page splice is the belt; the ports are the braces, kept for the browsers
where they do work. If you replace this with a proper API, that is the problem
you have to solve, and it is the single biggest improvement available.

## Processes

```
ASCENDRA.py                 text menu: 1 = log in, 2 = start the desk
   └─ connect.py            Zerodha OAuth; writes kite_token.json
   └─ desk.py               HTTP server :5055, opens the browser
         └─ FORMATIONS LIVE.py   child process, env FM_CHILD=1, :5056
SMC NEW.py                  started separately, :5057
COMMODITIES LIVE.py         started separately, :5058
```

`FM_CHILD=1` tells the Patterns engine it has no console of its own, so it
exits instead of waiting on `input()` — otherwise it swallows the keystrokes
meant for the desk's menu.

## The scan loop, same shape in every engine

```
every FAST_EVERY seconds   quote the live price on everything on the books,
                           mark open positions, republish
every FULL_EVERY seconds   rescan the universe for new setups
```

Patterns uses 120 s for the F&O names and 900 s for everything else. SMC
rescans hourly, because its structure is read from the daily chart and a daily
candle cannot change until the close. Daily candles are cached per day in
`DATA/formations_daily.json` and `DATA/smc2_daily.json` so a restart costs one
request per stock rather than a full rebuild.

## Universe selection

```python
inst = kite.instruments("NSE")
tokens = {i["tradingsymbol"]: i["instrument_token"] for i in inst
          if i.get("segment") == "NSE"
          and i.get("instrument_type") in ("EQ", "BE")}
```

`("EQ", "BE")` matters. It read `== "EQ"` until 23 Oct 2026, which silently
excluded every trade-to-trade stock — the engines never downloaded a single
candle for HFCL, STLTECH, HEG, DIACABS or LOTUSDEV, and nothing in the logs
said so. The same three lines exist in `FORMATIONS LIVE.py`, `SMC NEW.py` and
`BUILD UNIVERSE.py`; keep them in step.

Symbols come from `DATA/fo_universe.json` (F&O names),
`DATA/ind_niftytotalmarket_list.csv` (name → industry) and, for SMC,
`DATA/mcap_1000cr.json` (every company over ₹1,000 crore).

## State machine for a call

```
WAITING ──price breaks the level──> BROKE ──pullback fills──> IN ──> DONE
   └──────────────── level never broke in time ─────────────> GONE
```

`BROKE` must stay visible on the dashboard. It was filtered out once on the
grounds that it was "not waiting", and that is exactly the state where the
trader needs to be watching — the level has gone and the pullback is where the
order goes.

## Front end

`WEBSITE/ascendra_desk.html` — one file, vanilla JavaScript, no framework, no
build. Tabs for Patterns, SMC, Commodities and the record. It reads the three
`const` blocks described above.

Position sizing lives in the page, not in the engines:

```javascript
const PAT = {
  FLOOR: 8,                         // ignore calls rated below 8 out of 10
  POTS: [
    {name:'POSITIONAL', from:'SWING',    cash:4000000, slot:400000},
    {name:'SWING',      from:'INTRADAY', cash:1000000, slot:200000}
  ]
};
```

Note the deliberate crossover: a call the Patterns engine labels `SWING`
(found on the daily chart) is traded from the *positional* pot, and one
labelled `INTRADAY` (hourly chart) from the *swing* pot. The engine's labels
describe the chart it was found on, not the holding period.

There is also an alert bell. Keep its two paths separate: only a **fill**
should make a sound, while every other event is logged silently. They were
merged once and the bell rang for calls that had not filled, which is worse
than no bell at all.

`ASCENDRA ENGINES.html` and `ASCENDRA RECORD.html` are small standalone status
pages.

## Suggested order of work for a new developer

1. Read `DATA_SCHEMA.md`, then open `ascendra_desk.html` and find the three
   marker pairs.
2. Replace the splice with a real API: engines expose JSON, the page polls.
   This removes the three-writers problem and makes the page small again.
3. Split `desk.py` (252 KB, one file).
4. Implement the mitigation rule in `SMC NEW.py`.
5. Add a tab for the overnight drivers (Accenture/Cognizant → Indian IT is the
   only link that survived a permutation test).

Do not change the rule sets, the cost assumptions or the sizing without being
asked. Those numbers were argued over at length and are the owner's decisions,
not implementation details.
