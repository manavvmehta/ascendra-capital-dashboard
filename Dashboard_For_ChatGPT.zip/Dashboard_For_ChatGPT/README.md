# ASCENDRA CAPITAL — a live trading desk for Indian equities

This is the source of a working, single-user trading dashboard. It scans NSE
stocks against several rule sets, records every call it makes, marks the open
ones to live price, and shows the whole book in a browser. It places **no
orders** — it is a research and record-keeping desk, and the human decides what
to trade.

It is **not** a Node / React / Next.js project. There is no `package.json`, no
`src/`, no `node_modules`, no build step and no bundler. If you were expecting
those, here is the honest mapping:

| What you asked for | What this project actually has |
|---|---|
| `src`, `app`, `pages`, `components` | `WEBSITE/ascendra_desk.html` — the entire UI in one file: markup, CSS and ~295 KB of vanilla JavaScript inline. No framework. |
| Backend / `api` | `5 LIVE FEED/*.py` — four independent Python programs, each with its own HTTP server |
| `package.json` / lockfile | `requirements.txt` — one real dependency (`kiteconnect`) |
| `vite.config.*` / `next.config.*` | none; nothing is compiled |
| Database schema / migrations | no database. Flat JSON files in `DATA/`, documented in `DATA_SCHEMA.md` |
| `.env.example` | `.env.example` here; the live file is `5 LIVE FEED/kite_keys.txt`, excluded on purpose |
| `public` | no separate assets; everything is inlined in the HTML |

Read `ARCHITECTURE.md` next — the one thing worth understanding before changing
anything is how the Python engines get their data into the HTML page, because
it is not an API call.

---

## Running it

```
pip install -r requirements.txt
cd "5 LIVE FEED"
python connect.py        # Zerodha login; writes kite_token.json. Needed daily.
python desk.py           # serves the dashboard at http://localhost:5055
python "SMC NEW.py"      # separate window
python "COMMODITIES LIVE.py"   # separate window
```

`desk.py` starts `FORMATIONS LIVE.py` itself as a child process, so that one
does not need its own window. On Windows the `.bat` files do the same thing by
double-click. `ASCENDRA.py` is a small text menu that wraps the login and the
desk.

Zerodha access tokens expire every single day regardless of uptime, so
`connect.py` has to be run each morning before the market opens. Every engine
checks the token's date on startup and refuses to run on a stale one rather
than failing halfway through a scan.

---

## The four engines

| Program | Port | What it looks for | Where it writes |
|---|---|---|---|
| `desk.py` | 5055 | serves the dashboard, launches Patterns, keeps `calls_log.csv` | `WEBSITE/ascendra_desk.html` |
| `FORMATIONS LIVE.py` | 5056 | classical chart patterns (double bottom, head & shoulders, flags…) rated out of 10 on daily and hourly charts | `DATA/formations_log.json`, `formations_live.json` |
| `SMC NEW.py` | 5057 | "smart money" structure: weekly+daily trend, a liquidity sweep, a demand block, a change of character; entry on the hourly | `DATA/smc2_log.json` |
| `COMMODITIES LIVE.py` | 5058 | MCX commodities breaking a 20-day high with TRIX and Choppiness filters | `DATA/cmd_log.json`, `cmd_bars.json` |

Each engine owns one tab of the dashboard and one record file. They do not talk
to each other.

### Supporting tools (not part of the live loop)

- `BUILD UNIVERSE.py` — downloads NSE's half-yearly market-cap spreadsheet,
  keeps every company over ₹1,000 crore (1,405 of them), then downloads three
  years of 15-minute candles for any that have no history yet. **Note:** NSE
  publishes that file in *lakhs*, not crores; the code divides by 100 and says
  so in a comment. Getting this wrong once produced a 2,753-name universe.
- `GLOBAL DRIVERS.py` — stdlib-only downloader for 110 world series (US
  indices, semiconductors, Asian indices, commodities, Indian ADRs) used in
  overnight-correlation research. Falls back from Yahoo to Stooq.
- `SETTLE THE RECORD.py`, `DATA/CHECK THE RECORD.py` — repair and audit the
  record files.
- `TIDY UP.py`, `ARCHIVE OLD DATA.py`, `MAKE A ZIP.py` — housekeeping.

---

## What is working, and what is not

Working and in daily use:

- All four engines run a full session without intervention.
- The Patterns tab produces rated calls live (a rating-9 double bottom in IGIL
  was its most recent).
- The records survive restarts and are marked to live price every minute.
- The dashboard needs no refresh; engines rewrite the page in place.

Known gaps, honestly stated:

- **`SMC NEW.py` is new.** Its rules were backtested but it has only been live
  for a few sessions and had produced no completed trade at the time this zip
  was made. Treat its P&L as unproven.
- **The "mitigation" rule is specified but not implemented.** In the SMC rule
  set an order block that has already been traded through should lose its
  strength. The code does not model this.
- **The BE series was invisible until 23 Oct 2026.** All three engines filtered
  Zerodha's instrument dump to `instrument_type == "EQ"`, which silently
  dropped trade-to-trade names (HFCL, STLTECH, HEG, DIACABS, LOTUSDEV). Fixed
  to accept `("EQ", "BE")`. Worth knowing because the same filter pattern
  appears in three files and could be reintroduced.
- **Research findings are not in the dashboard yet.** Overnight-correlation work
  found one robust link — Accenture and Cognizant moving Indian IT, about +13
  points of accuracy over the base rate — and showed that most apparent
  theme links do not survive a permutation test. None of this is wired into a
  tab.
- `desk.py` is 252 KB in one file and is the least tidy part of the project.

## Conventions worth preserving

- **Position sizing is in rupees, never in risk multiples.** Slots: ₹2 lakh for
  intraday/swing, ₹4 lakh for positional. Round-trip costs used throughout:
  0.059% cash intraday, 0.062% stock futures, 0.222% delivery.
- **No lookahead, anywhere.** Decisions use only closed candles; a fill happens
  at the *next* candle's open; a target is never claimed on the fill candle
  because a single candle cannot say whether the high or the low came first.
  Several of this project's worst bugs were lookahead, and the comments in the
  code record each one.
- **`ascendra_desk.html` is CRLF throughout.** Any edit must preserve that, and
  the inline `<script>` should be syntax-checked after a change.
